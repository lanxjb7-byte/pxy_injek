package com.lanx.fpsboost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 101;
    private final int BG = Color.rgb(9, 10, 15);
    private final int PANEL = Color.rgb(20, 22, 30);
    private final int RED = Color.rgb(255, 48, 75);
    private final int MUTED = Color.rgb(150, 155, 171);
    private final int WHITE = Color.rgb(245, 246, 250);
    private LinearLayout fileContainer;
    private TextView countLabel, statusLabel, modeLabel;
    private Button powerButton;
    private boolean enabled = false;
    private final ArrayList<ImportedFile> files = new ArrayList<>();
    private SharedPreferences prefs;

    private static class ImportedFile {
        String name, path;
        long size;
        ImportedFile(String n, String p, long s) { name=n; path=p; size=s; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("fps_boost", MODE_PRIVATE);
        loadState();
        buildUi();
        renderPower();
        renderFiles();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(28));
        scroll.addView(page);
        setContentView(scroll);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(18));
        TextView logo = text("ϟ", 30, RED, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(roundBg(Color.rgb(38,16,25), RED, 16));
        header.addView(logo, new LinearLayout.LayoutParams(dp(52), dp(52)));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(12), 0, 0, 0);
        TextView title = text("FPS BOOST", 22, WHITE, true);
        title.setLetterSpacing(0.08f);
        brand.addView(title);
        TextView sub = text("PERFORMANCE CONTROL PANEL", 10, MUTED, true);
        sub.setPadding(0, dp(4), 0, 0);
        brand.addView(sub);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("LOCAL MODE", 10, Color.rgb(53,230,154), true);
        header.addView(badge);
        page.addView(header);

        LinearLayout control = panel();
        addEyebrow(control, "SYSTEM CONTROL");
        modeLabel = text("STANDBY", 12, MUTED, true);
        modeLabel.setPadding(0, dp(5), 0, dp(10));
        control.addView(modeLabel);
        powerButton = new Button(this);
        powerButton.setText("⏻\nOFF");
        powerButton.setTextSize(20);
        powerButton.setTypeface(null, Typeface.BOLD);
        powerButton.setTextColor(RED);
        powerButton.setBackground(roundBg(Color.rgb(45,16,25), RED, 100));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(140), dp(140));
        pp.gravity = Gravity.CENTER_HORIZONTAL;
        pp.topMargin = dp(8); pp.bottomMargin = dp(12);
        control.addView(powerButton, pp);
        powerButton.setOnClickListener(v -> {
            enabled = !enabled;
            renderPower(); saveState();
            toast(enabled ? "Status antarmuka ON" : "Status antarmuka OFF");
        });
        statusLabel = text("● BOOST NONAKTIF", 12, RED, true);
        statusLabel.setGravity(Gravity.CENTER);
        control.addView(statusLabel);
        TextView note = text("Sakelar hanya mengubah status pada aplikasi. Ini tidak mengubah performa sistem atau menjamin FPS meningkat.", 11, MUTED, false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(2), dp(12), dp(2), 0);
        control.addView(note);
        page.addView(control);

        LinearLayout importPanel = panel();
        addEyebrow(importPanel, "FILE MANAGER");
        TextView importTitle = text("Import File", 17, WHITE, true);
        importTitle.setPadding(0, dp(5), 0, dp(14));
        importPanel.addView(importTitle);
        TextView hint = text("Pilih satu atau banyak file dari penyimpanan perangkat.", 12, MUTED, false);
        importPanel.addView(hint);
        Button choose = button("＋ PILIH FILE", true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(48));
        bp.topMargin = dp(14);
        importPanel.addView(choose, bp);
        choose.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, PICK_FILES);
        });
        TextView privateNote = text("File yang diimpor disalin ke penyimpanan privat aplikasi ini, bukan ke folder Free Fire.", 11, MUTED, false);
        privateNote.setPadding(0, dp(12), 0, 0);
        importPanel.addView(privateNote);
        page.addView(importPanel);

        LinearLayout listPanel = panel();
        LinearLayout listHead = new LinearLayout(this);
        listHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView listTitle = text("Daftar File", 17, WHITE, true);
        listHead.addView(listTitle, new LinearLayout.LayoutParams(0, -2, 1));
        Button clear = button("HAPUS SEMUA", false);
        listHead.addView(clear);
        listPanel.addView(listHead);
        clear.setOnClickListener(v -> {
            if (files.isEmpty()) { toast("Daftar file sudah kosong"); return; }
            new AlertDialog.Builder(this).setTitle("Hapus semua file?")
                .setMessage("File yang sudah disalin ke penyimpanan privat aplikasi juga akan dihapus.")
                .setNegativeButton("BATAL", (d,w)->{})
                .setPositiveButton("HAPUS", (d,w)->{
                    for (ImportedFile f : files) { if (f.path != null) new File(f.path).delete(); }
                    files.clear(); saveState(); renderFiles(); toast("Semua file dihapus");
                }).show();
        });
        countLabel = text("0 FILE", 11, MUTED, true);
        countLabel.setPadding(0, dp(12), 0, dp(8));
        listPanel.addView(countLabel);
        fileContainer = new LinearLayout(this);
        fileContainer.setOrientation(LinearLayout.VERTICAL);
        listPanel.addView(fileContainer);
        page.addView(listPanel);

        TextView footer = text("PXY PROJECT · LOCAL FILE\nAndroid membatasi akses ke Android/data aplikasi lain.", 10, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(dp(10), dp(8), dp(10), 0);
        page.addView(footer);
    }

    private void addEyebrow(LinearLayout parent, String s) {
        TextView t = text(s, 10, MUTED, true);
        t.setLetterSpacing(0.13f);
        parent.addView(t);
    }

    private LinearLayout panel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundBg(PANEL, Color.rgb(41,45,57), 20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        box.setLayoutParams(lp);
        return box;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(11); b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(WHITE);
        b.setBackground(roundBg(primary ? RED : Color.rgb(36,39,51), primary ? RED : Color.rgb(56,61,75), 12));
        return b;
    }

    private android.graphics.drawable.GradientDrawable roundBg(int color, int stroke, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke); return d;
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void renderPower() {
        if (powerButton == null) return;
        powerButton.setText(enabled ? "⏻\nON" : "⏻\nOFF");
        powerButton.setTextColor(enabled ? Color.rgb(53,230,154) : RED);
        powerButton.setBackground(roundBg(enabled ? Color.rgb(15,48,35) : Color.rgb(45,16,25),
                enabled ? Color.rgb(53,230,154) : RED, 100));
        statusLabel.setText(enabled ? "● BOOST UI AKTIF" : "● BOOST NONAKTIF");
        statusLabel.setTextColor(enabled ? Color.rgb(53,230,154) : RED);
        modeLabel.setText(enabled ? "ACTIVE UI" : "STANDBY");
    }

    private void renderFiles() {
        if (fileContainer == null) return;
        fileContainer.removeAllViews();
        countLabel.setText(files.size() + " FILE");
        if (files.isEmpty()) {
            TextView empty = text("Belum ada file dipilih.\nTekan PILIH FILE untuk memulai.", 12, MUTED, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(10), dp(20), dp(10), dp(20));
            fileContainer.addView(empty); return;
        }
        for (int i = 0; i < files.size(); i++) {
            final ImportedFile f = files.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(10), dp(8), dp(10));
            row.setBackground(roundBg(Color.rgb(13,15,21), Color.rgb(40,44,56), 13));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(8);
            fileContainer.addView(row, rp);

            String ext = "FILE";
            int dot = f.name.lastIndexOf('.');
            if (dot >= 0 && dot < f.name.length()-1) ext = f.name.substring(dot+1).toUpperCase();
            if (ext.length() > 5) ext = ext.substring(0,5);
            TextView icon = text(ext, 9, Color.rgb(255,129,145), true);
            icon.setGravity(Gravity.CENTER);
            icon.setBackground(roundBg(Color.rgb(40,20,27), Color.rgb(70,35,47), 9));
            row.addView(icon, new LinearLayout.LayoutParams(dp(38), dp(42)));

            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setPadding(dp(10), 0, dp(6), 0);
            TextView name = text(f.name, 12, WHITE, true);
            name.setMaxLines(2);
            info.addView(name);
            TextView size = text(formatSize(f.size), 10, MUTED, false);
            size.setPadding(0, dp(4), 0, 0);
            info.addView(size);
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

            Button del = button("HAPUS", false);
            del.setTextColor(Color.rgb(255,129,145));
            del.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Hapus file?")
                .setMessage(f.name)
                .setNegativeButton("BATAL", (d,w)->{})
                .setPositiveButton("HAPUS", (d,w)->{
                    if (f.path != null) new File(f.path).delete();
                    files.remove(f); saveState(); renderFiles(); toast("File dihapus");
                }).show());
            row.addView(del);
        }
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double n = bytes / 1024.0;
        String[] u = {"KB","MB","GB","TB"}; int i=0;
        while(n >= 1024 && i < u.length-1) { n/=1024; i++; }
        return new DecimalFormat("#,##0.##").format(n) + " " + u[i];
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null) return;
        int added = 0;
        if (data.getClipData() != null) {
            for (int i=0; i<data.getClipData().getItemCount(); i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                if (importUri(uri)) added++;
            }
        } else if (data.getData() != null) {
            if (importUri(data.getData())) added++;
        }
        saveState(); renderFiles();
        toast(added > 0 ? added + " file berhasil diimpor ke aplikasi" : "Tidak ada file baru yang diimpor");
    }

    private boolean importUri(Uri uri) {
        try {
            String name = "file";
            long size = 0;
            try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    int si = c.getColumnIndex(OpenableColumns.SIZE);
                    if (ni >= 0 && c.getString(ni) != null) name = c.getString(ni);
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                }
            }
            for (ImportedFile f : files) if (f.name.equals(name)) return false;
            File dir = new File(getFilesDir(), "imported");
            if (!dir.exists() && !dir.mkdirs()) return false;
            String safe = name.replaceAll("[^a-zA-Z0-9._-]", "_");
            File target = new File(dir, System.currentTimeMillis() + "_" + safe);
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(target)) {
                if (in == null) return false;
                byte[] buffer = new byte[8192]; int n;
                while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            }
            files.add(new ImportedFile(name, target.getAbsolutePath(), target.length()));
            return true;
        } catch (Exception e) {
            toast("Gagal mengimpor file: " + e.getMessage());
            return false;
        }
    }

    private void saveState() {
        try {
            JSONArray arr = new JSONArray();
            for (ImportedFile f : files) {
                JSONObject o = new JSONObject();
                o.put("name", f.name); o.put("path", f.path); o.put("size", f.size);
                arr.put(o);
            }
            prefs.edit().putBoolean("enabled", enabled).putString("files", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void loadState() {
        enabled = prefs.getBoolean("enabled", false);
        try {
            JSONArray arr = new JSONArray(prefs.getString("files", "[]"));
            for (int i=0; i<arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String path = o.optString("path", "");
                File f = new File(path);
                if (f.exists() && f.isFile()) files.add(new ImportedFile(o.optString("name", f.getName()), path, f.length()));
            }
        } catch (Exception ignored) {}
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
